# DealGuard deployment — Render

Current production target: Render Web Service (Node runtime).

## Render environment variables

Set only these browser-safe values on the web service:

- `NEXT_PUBLIC_SUPABASE_URL` = the DealGuard Supabase project URL
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` = the DealGuard publishable key
- `NODE_VERSION` = `22.16.0`

Do **not** add the Supabase service-role key, cron secret or Resend API key to the frontend service. Resend credentials stay in Supabase Vault and are used only by the reminder worker.

## Current ZIP-based Render build

The GitHub mobile upload flattened folders, so the repository currently keeps the canonical source as `dealguard-deploy-ready.zip`.

Build command:

```bash
rm -rf deploy && mkdir deploy && unzip -q dealguard-deploy-ready.zip -d deploy && rm -rf deploy/supabase/functions && cd deploy && npm install --no-audit --no-fund && npm run build
```

Start command:

```bash
cd deploy && npm start -- -H 0.0.0.0 -p $PORT
```

The `supabase/functions` directory is removed only from the Next.js build copy because that Edge Function uses Deno and is deployed separately in Supabase.

## Auth URLs

For the current Render URL:

- Site URL: `https://dealguard-beta.onrender.com`
- Allowed redirect: `https://dealguard-beta.onrender.com/auth/callback`

## Before external beta

1. Verify a custom Resend sending domain.
2. Configure a production sender address in Supabase Vault.
3. Send one real reminder to a non-owner test address.
4. Keep email/password as the supported login path until Google OAuth is configured.
5. Review `docs/LAUNCH_READINESS.md`.
