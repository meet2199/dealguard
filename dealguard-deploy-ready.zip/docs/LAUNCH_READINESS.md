# DealGuard private-beta launch readiness

## Ready now

- Next.js production build has passed on Render.
- Email/password authentication is live.
- Creator-owned RLS is enabled on public tables.
- Deal create, edit, status change and delete flows are implemented.
- Payment, deliverable and usage-right reminder triggers are live.
- Reminder preferences reschedule existing future pending reminders.
- Scheduled reminder worker runs every 15 minutes.
- Product analytics records minimal beta behavior in an RLS-protected table.
- Mobile navigation, Settings access, mobile deal cards and bottom-sheet forms are implemented.

## Required before inviting external beta users

1. Verify a custom sending domain in Resend and configure a production `from` address.
2. Run one real reminder email to a non-owner test address after the domain is verified.
3. Keep email/password as the supported login method unless Google OAuth is configured.
4. Review privacy/terms copy before a public launch.
5. Move off Render Free if cold starts become disruptive for beta users.

## Optional after validation

- Google OAuth.
- Supabase Pro security features such as leaked-password protection.
- Custom production domain.
- Team/agency accounts.
- Contract parsing and other AI features.
