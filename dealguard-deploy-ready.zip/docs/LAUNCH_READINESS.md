# DealGuard private-beta launch readiness

## Ready now

- Next.js production build workflow is proven on Render.
- Email/password authentication is live.
- Google OAuth is hidden by default until it is configured.
- Creator-owned RLS is enabled on product and feedback tables.
- Deal create, edit, status change and delete flows are implemented.
- Payment, deliverable and usage-right reminder triggers are live.
- Reminder preferences reschedule existing future pending reminders.
- Scheduled reminder worker runs every 15 minutes.
- Product analytics records minimal beta behavior in an RLS-protected table.
- Structured in-app beta feedback / bug reporting is implemented.
- Public beta landing page is implemented.
- Privacy Policy and Beta Terms pages are implemented for private-beta use.
- Mobile navigation, Settings access, mobile deal cards and bottom-sheet forms are implemented.

## Private beta can start with these limitations disclosed

1. Email/password is the supported sign-in method.
2. Reminder scheduling works, but arbitrary external reminder-email delivery remains limited until a Resend sending domain is verified.
3. The product is an organizational tool; creators should keep original contracts/invoices and verify important dates themselves.
4. The legal pages are beta product copy and should be reviewed by qualified counsel before commercial/public launch.

## Required before wider public beta / paid launch

1. Verify a custom sending domain in Resend and configure a production `from` address.
2. Run real reminder emails to multiple non-owner test addresses.
3. Add a custom product domain.
4. Test password reset/account recovery end-to-end.
5. Configure Google OAuth if it will be advertised as a sign-in method.
6. Review privacy/terms with qualified counsel.
7. Move off Render Free if cold starts become disruptive.

## Beta measurement

Use auth users, profiles, deals, `product_events`, reminders and `beta_feedback` to measure:
- onboarding completion
- first-deal activation
- repeat app opens
- deal updates
- reminder-setting changes
- feedback volume and rating
- reminder failures

See `docs/BETA_LAUNCH_PLAN.md` for the tester cohort and targets.
