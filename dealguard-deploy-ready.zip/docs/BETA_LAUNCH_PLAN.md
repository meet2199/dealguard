# DealGuard Private Beta Launch Plan

## Cohort
- 20–30 solo creators / UGC creators
- Prefer creators with 5–30 paid collaborations per year
- Start with 5 high-touch testers, then 10, then the remaining cohort after critical bugs are fixed

## Activation event
A creator is activated when they add a first deal with a payment due date and usage-rights expiry.

## Core beta metrics
1. Signup → onboarding completion
2. Onboarding → first deal created
3. First deal → deal updated within 7 days
4. Reminder schedule changed
5. Return app opens within 7 days
6. Feedback submitted
7. Critical errors / failed reminders

## Working targets
- 70%+ of invited creators create a first deal
- 50%+ return within 7 days
- 30%+ enter 2 or more real deals
- Fewer than 10% encounter a blocking bug
- At least 10 substantive feedback submissions across the cohort

## Tester tasks
1. Create account and complete onboarding
2. Add one current or recent brand collaboration
3. Change the deal status
4. Edit one date or payment term
5. Check Money Watch and Rights Watch
6. Open Reminder Settings
7. Submit one feedback report from inside DealGuard

## Ask after 3–7 days
- What did you expect DealGuard to do that it did not?
- Which screen was most useful?
- What was confusing or unnecessary?
- Would you trust DealGuard to replace your current tracking method? Why or why not?
- What single feature would make you use it every week?

## Do not build from one request
Group feedback into repeated problems. Prioritize issues that block activation, hide money, create wrong reminders, or reduce trust.

## Launch blockers before wider public beta
- Verify production sending domain for arbitrary reminder emails
- Configure Google OAuth or keep the button disabled
- Add a custom product domain
- Review Privacy Policy / Terms with qualified counsel before commercial public launch
- Test password reset / account recovery
- Test reminder delivery with at least two beta accounts
