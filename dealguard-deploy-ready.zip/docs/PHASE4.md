# DealGuard Phase 4 — Beta-ready product polish

Phase 4 turns the live Phase 3 foundation into a more usable private-beta product.

## Included in this build

- Edit an existing deal from the deal detail screen.
- Delete a deal with confirmation; related deliverables, payments, usage rights and reminders cascade-delete.
- Editing due dates automatically re-runs the existing reminder triggers.
- Payment terms are visible and editable.
- Reminder defaults can be edited in Settings using comma-separated day windows.
- Email reminder master switch remains available.
- Minimal privacy-conscious product analytics via `public.product_events`.
- Mobile deal-detail actions and reminder settings are responsive.
- `supabase/functions/**` is excluded from the Next.js TypeScript build because Edge Functions run on Deno, not Node/Next.js.

## Analytics events

The beta client records only product behavior needed for validation, such as app opens, deal creation/update/delete, status changes and reminder-setting changes. It does not need deal notes, email bodies or other content fields.

## Reminder setting behavior

Updated reminder defaults are used for new deals and whenever an existing deal is edited. Existing untouched deals keep their current already-scheduled reminders.

## Production notes

Resend still requires a verified sending domain before DealGuard can email arbitrary creator addresses. The reminder engine itself is already connected and tested.
