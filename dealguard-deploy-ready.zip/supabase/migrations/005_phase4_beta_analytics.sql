-- DealGuard Phase 4 — minimal privacy-conscious beta product analytics.
-- Stores behavioral product events only; no email/body/content data is required.

create table if not exists public.product_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  event_name text not null check (char_length(event_name) between 1 and 80),
  entity_type text check (entity_type is null or char_length(entity_type) <= 40),
  entity_id uuid,
  properties jsonb not null default '{}'::jsonb check (jsonb_typeof(properties) = 'object'),
  created_at timestamptz not null default now()
);

create index if not exists product_events_user_created_idx
  on public.product_events(user_id, created_at desc);
create index if not exists product_events_name_created_idx
  on public.product_events(event_name, created_at desc);

alter table public.product_events enable row level security;

revoke all on table public.product_events from anon;
grant select, insert on table public.product_events to authenticated;

drop policy if exists "product_events_select_own" on public.product_events;
create policy "product_events_select_own"
  on public.product_events
  for select
  to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "product_events_insert_own" on public.product_events;
create policy "product_events_insert_own"
  on public.product_events
  for insert
  to authenticated
  with check ((select auth.uid()) = user_id);
