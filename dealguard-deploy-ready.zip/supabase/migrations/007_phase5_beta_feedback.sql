create table if not exists public.beta_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null default 'general' check (kind in ('bug','confusing','idea','general')),
  rating integer check (rating is null or rating between 1 and 5),
  message text not null check (char_length(message) between 5 and 2000),
  page text check (page is null or char_length(page) <= 80),
  status text not null default 'new' check (status in ('new','reviewed','planned','resolved','closed')),
  created_at timestamptz not null default now()
);

create index if not exists beta_feedback_user_created_idx on public.beta_feedback(user_id, created_at desc);
create index if not exists beta_feedback_status_created_idx on public.beta_feedback(status, created_at desc);

alter table public.beta_feedback enable row level security;
revoke all on table public.beta_feedback from anon;
grant select, insert on table public.beta_feedback to authenticated;

drop policy if exists "beta_feedback_select_own" on public.beta_feedback;
create policy "beta_feedback_select_own" on public.beta_feedback for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "beta_feedback_insert_own" on public.beta_feedback;
create policy "beta_feedback_insert_own" on public.beta_feedback for insert to authenticated with check ((select auth.uid()) = user_id);
