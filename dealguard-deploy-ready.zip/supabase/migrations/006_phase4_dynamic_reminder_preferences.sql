-- Phase 4.2: make reminder triggers preference-driven and resync existing active deals

create or replace function public.sync_payment_reminders()
returns trigger
language plpgsql
set search_path to ''
as $function$
declare
  v_user_id uuid;
  v_due date;
  v_at timestamptz;
  v_days integer;
  v_due_days integer[];
  v_overdue_days integer[];
begin
  select d.user_id into v_user_id
  from public.deals d
  where d.id = new.deal_id;

  delete from public.reminders
  where source_type = 'payment'
    and source_id = new.id
    and status in ('pending','failed','processing');

  if new.status = 'Paid' or new.due_date is null or v_user_id is null then
    return new;
  end if;

  select coalesce(np.payment_due_days, array[3,0]),
         coalesce(np.payment_overdue_days, array[1,7])
    into v_due_days, v_overdue_days
  from public.notification_preferences np
  where np.user_id = v_user_id;

  v_due_days := coalesce(v_due_days, array[3,0]);
  v_overdue_days := coalesce(v_overdue_days, array[1,7]);
  v_due := new.due_date;

  if v_due >= current_date then
    foreach v_days in array v_due_days loop
      if v_days >= 0 then
        v_at := public.local_reminder_time(v_user_id, v_due - v_days);
        if v_at > now() then
          insert into public.reminders(user_id, deal_id, reminder_type, reminder_at, source_type, source_id)
          values (v_user_id, new.deal_id, 'payment_due_' || v_days::text, v_at, 'payment', new.id)
          on conflict do nothing;
        end if;
      end if;
    end loop;
  else
    insert into public.reminders(user_id, deal_id, reminder_type, reminder_at, source_type, source_id)
    values (v_user_id, new.deal_id, 'payment_overdue_now', now(), 'payment', new.id)
    on conflict do nothing;
  end if;

  foreach v_days in array v_overdue_days loop
    if v_days >= 0 then
      v_at := public.local_reminder_time(v_user_id, v_due + v_days);
      if v_at > now() then
        insert into public.reminders(user_id, deal_id, reminder_type, reminder_at, source_type, source_id)
        values (v_user_id, new.deal_id, 'payment_overdue_' || v_days::text, v_at, 'payment', new.id)
        on conflict do nothing;
      end if;
    end if;
  end loop;

  return new;
end;
$function$;

create or replace function public.sync_deliverable_reminders()
returns trigger
language plpgsql
set search_path to ''
as $function$
declare
  v_user_id uuid;
  v_days integer;
  v_at timestamptz;
  v_due_days integer[];
begin
  select d.user_id into v_user_id
  from public.deals d
  where d.id = new.deal_id;

  delete from public.reminders
  where source_type = 'deliverable'
    and source_id = new.id
    and status in ('pending','failed','processing');

  if new.due_date is null or v_user_id is null or lower(coalesce(new.status,'')) in ('complete','completed','published') then
    return new;
  end if;

  select coalesce(np.deliverable_due_days, array[3,1])
    into v_due_days
  from public.notification_preferences np
  where np.user_id = v_user_id;

  v_due_days := coalesce(v_due_days, array[3,1]);

  foreach v_days in array v_due_days loop
    if v_days >= 0 then
      v_at := public.local_reminder_time(v_user_id, new.due_date - v_days);
      if v_at > now() then
        insert into public.reminders(user_id, deal_id, reminder_type, reminder_at, source_type, source_id)
        values (v_user_id, new.deal_id, 'deliverable_due_' || v_days::text, v_at, 'deliverable', new.id)
        on conflict do nothing;
      end if;
    end if;
  end loop;

  return new;
end;
$function$;

create or replace function public.sync_rights_reminders()
returns trigger
language plpgsql
set search_path to ''
as $function$
declare
  v_user_id uuid;
  v_days integer;
  v_at timestamptz;
  v_expiry_days integer[];
begin
  select d.user_id into v_user_id
  from public.deals d
  where d.id = new.deal_id;

  delete from public.reminders
  where source_type = 'usage_right'
    and source_id = new.id
    and status in ('pending','failed','processing');

  if new.end_date is null or v_user_id is null or new.end_date < current_date then
    return new;
  end if;

  select coalesce(np.rights_expiry_days, array[30,14,7])
    into v_expiry_days
  from public.notification_preferences np
  where np.user_id = v_user_id;

  v_expiry_days := coalesce(v_expiry_days, array[30,14,7]);

  foreach v_days in array v_expiry_days loop
    if v_days >= 0 then
      v_at := public.local_reminder_time(v_user_id, new.end_date - v_days);
      if v_at > now() then
        insert into public.reminders(user_id, deal_id, reminder_type, reminder_at, source_type, source_id)
        values (v_user_id, new.deal_id, 'rights_expiry_' || v_days::text, v_at, 'usage_right', new.id)
        on conflict do nothing;
      end if;
    end if;
  end loop;

  return new;
end;
$function$;

create or replace function public.resync_reminders_after_preferences_change()
returns trigger
language plpgsql
set search_path to ''
as $function$
begin
  update public.payments p
  set due_date = p.due_date
  from public.deals d
  where p.deal_id = d.id
    and d.user_id = new.user_id;

  update public.deliverables dl
  set due_date = dl.due_date
  from public.deals d
  where dl.deal_id = d.id
    and d.user_id = new.user_id;

  update public.usage_rights ur
  set end_date = ur.end_date
  from public.deals d
  where ur.deal_id = d.id
    and d.user_id = new.user_id;

  return new;
end;
$function$;

drop trigger if exists notification_preferences_resync_reminders on public.notification_preferences;
create trigger notification_preferences_resync_reminders
after update of payment_due_days, payment_overdue_days, rights_expiry_days, deliverable_due_days
on public.notification_preferences
for each row
execute function public.resync_reminders_after_preferences_change();
