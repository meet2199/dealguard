import AuthCard from "@/components/auth-card";
import { isGoogleAuthEnabled, isSupabaseConfigured } from "@/lib/config";

export default function LoginPage() {
  return <AuthCard mode="login" configured={isSupabaseConfigured()} googleEnabled={isGoogleAuthEnabled()} />;
}
