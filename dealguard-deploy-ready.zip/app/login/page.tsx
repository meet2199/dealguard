import AuthCard from "@/components/auth-card";
import { isSupabaseConfigured } from "@/lib/config";

export default function LoginPage() {
  return <AuthCard mode="login" configured={isSupabaseConfigured()} />;
}
