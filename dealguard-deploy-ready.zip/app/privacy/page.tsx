import Link from "next/link";

export default function PrivacyPage() {
  return <main className="legal-page"><div className="legal-shell"><Link href="/" className="legal-back">← DealGuard</Link><span className="eyebrow">PRIVATE BETA</span><h1>Privacy Policy</h1><p className="legal-date">Effective September 26, 2026</p>
  <section><h2>What DealGuard stores</h2><p>DealGuard stores the account information you provide and the creator-business data you enter, such as brands, campaign details, deal values, deliverables, payment deadlines, usage-rights dates, reminder preferences and feedback.</p></section>
  <section><h2>How the data is used</h2><p>We use this information to operate the product, secure creator-owned records, generate your dashboards and reminder schedules, troubleshoot issues and improve the private beta. Product events may record actions such as opening the app, creating or updating a deal, changing reminder settings or submitting feedback. These events are used for product analytics and do not include your password.</p></section>
  <section><h2>Service providers</h2><p>DealGuard currently uses Supabase for authentication and database services, Render for application hosting and Resend for transactional reminder email infrastructure. Those providers process data as needed to deliver their services.</p></section>
  <section><h2>Email reminders</h2><p>Reminder email delivery is a beta feature. Until a production sending domain is verified, email delivery may be limited even when reminder scheduling is active.</p></section>
  <section><h2>Data access and deletion</h2><p>Your workspace data is protected by user-level access rules. During private beta, use the in-app feedback channel to request help with access, correction or deletion of your beta account and associated creator data.</p></section>
  <section><h2>Beta changes</h2><p>DealGuard is under active development. This policy may be updated as integrations, hosting, analytics or product functionality change. Material changes will be reflected in an updated effective date.</p></section>
  <div className="legal-actions"><Link href="/terms" className="button secondary">Read Beta Terms</Link><Link href="/signup" className="button primary">Join beta</Link></div></div></main>;
}
