import AuthCard from "@/components/auth-card";
import { isGoogleAuthEnabled, isSupabaseConfigured } from "@/lib/config";

export default function SignupPage() {
  return <AuthCard mode="signup" configured={isSupabaseConfigured()} googleEnabled={isGoogleAuthEnabled()} />;
}
