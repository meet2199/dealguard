import AuthCard from "@/components/auth-card";
import { isSupabaseConfigured } from "@/lib/config";

export default function SignupPage() {
  return <AuthCard mode="signup" configured={isSupabaseConfigured()} />;
}
