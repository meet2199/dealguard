import { redirect } from "next/navigation";
import OnboardingForm from "@/components/onboarding-form";
import { isSupabaseConfigured } from "@/lib/config";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  if (!isSupabaseConfigured()) redirect("/dashboard");

  const supabase = await createClient();
  const { data: authData } = await supabase.auth.getUser();
  const user = authData.user;
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name,country,default_currency,creator_category,main_platform,deals_per_month,onboarding_completed")
    .eq("id", user.id)
    .maybeSingle();

  if (profile?.onboarding_completed) redirect("/dashboard");

  return (
    <OnboardingForm
      userId={user.id}
      defaults={{
        fullName: profile?.full_name || String(user.user_metadata?.full_name || user.email?.split("@")[0] || ""),
        country: profile?.country || "",
        currency: profile?.default_currency || "USD",
        creatorCategory: profile?.creator_category || "UGC Creator",
        mainPlatform: profile?.main_platform || "Instagram",
        dealsPerMonth: profile?.deals_per_month || "0–2",
      }}
    />
  );
}
