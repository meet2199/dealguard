import Link from "next/link";

export default function TermsPage() {
  return <main className="legal-page"><div className="legal-shell"><Link href="/" className="legal-back">← DealGuard</Link><span className="eyebrow">PRIVATE BETA</span><h1>Beta Terms of Use</h1><p className="legal-date">Effective September 26, 2026</p>
  <section><h2>Private beta</h2><p>DealGuard is an early-stage beta product provided for testing and feedback. Features may change, be unavailable temporarily or contain defects. Beta access may be limited or discontinued.</p></section>
  <section><h2>Your responsibility</h2><p>You are responsible for verifying contract terms, payment dates, usage-rights periods, tax obligations and other business information you enter. DealGuard is an organizational tool and does not provide legal, accounting or financial advice.</p></section>
  <section><h2>Your content</h2><p>You retain ownership of the creator and deal information you submit. You grant DealGuard permission to process that information only as needed to operate, secure and improve the service.</p></section>
  <section><h2>Acceptable use</h2><p>Do not use DealGuard to access another creator's data, interfere with the service, abuse authentication or reminder systems, upload unlawful material or attempt to bypass security controls.</p></section>
  <section><h2>No guarantee</h2><p>Because this is a private beta, the service is provided on an as-available basis. Do not rely on DealGuard as the sole record of a payment deadline, contract obligation or rights expiry. Keep copies of important contracts and invoices.</p></section>
  <section><h2>Feedback</h2><p>Beta feedback may be used to improve DealGuard. Do not include passwords, payment-card data or other secrets in feedback messages.</p></section>
  <section><h2>Changes</h2><p>These beta terms may change as the product matures. Continued beta use after an updated effective date means you accept the revised terms.</p></section>
  <div className="legal-actions"><Link href="/privacy" className="button secondary">Read Privacy Policy</Link><Link href="/signup" className="button primary">Join beta</Link></div></div></main>;
}
