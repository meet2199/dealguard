import Link from "next/link";

export default function Home() {
  return (
    <main className="landing-page">
      <nav className="landing-nav">
        <Link href="/" className="landing-logo"><span className="logo-mark">DG</span><span><strong>DealGuard</strong><small>Creator money & rights</small></span></Link>
        <div><Link href="/login" className="button secondary">Sign in</Link><Link href="/signup" className="button primary">Join private beta</Link></div>
      </nav>
      <section className="landing-hero">
        <span className="beta-chip large">PRIVATE BETA</span>
        <h1>Never lose track of money after a brand deal.</h1>
        <p>DealGuard keeps payment deadlines, content deliverables and usage-rights expiries in one creator-first workspace.</p>
        <div className="landing-actions"><Link href="/signup" className="button primary">Start free beta</Link><Link href="/login" className="button secondary">I already have an account</Link></div>
        <small>No card required · Free during private beta</small>
      </section>
      <section className="landing-features">
        <article><span>01</span><h2>Money Watch</h2><p>See what brands still owe you, when payment is due and what is overdue.</p></article>
        <article><span>02</span><h2>Rights Watch</h2><p>Know when paid usage or content rights expire so renewal revenue does not disappear.</p></article>
        <article><span>03</span><h2>Deadline Watch</h2><p>Track deliverables and important dates without another spreadsheet or calendar maze.</p></article>
      </section>
      <section className="landing-beta-note">
        <div><span className="eyebrow">WHY PRIVATE BETA</span><h2>Built with creators, not around them.</h2><p>We are inviting a small group of creators to test the real workflow, report friction and shape what DealGuard becomes next.</p></div>
        <Link href="/signup" className="button primary">Become a beta tester</Link>
      </section>
      <footer className="landing-footer"><span>DealGuard · Private beta</span><div><Link href="/privacy">Privacy</Link><Link href="/terms">Beta Terms</Link><Link href="/login">Sign in</Link></div></footer>
    </main>
  );
}
