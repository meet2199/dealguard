import { redirect } from "next/navigation";
import DealGuardApp from "@/components/dealguard-app";
import { demoDeals } from "@/lib/demo-data";
import { isSupabaseConfigured } from "@/lib/config";
import { createClient } from "@/lib/supabase/server";
import type { AppUser, Deal, NotificationPreferences, PaymentStatus, ReminderSummary } from "@/lib/types";

export const dynamic = "force-dynamic";

function normalizeDeal(row: any): Deal {
  const brand = Array.isArray(row.brands) ? row.brands[0] : row.brands;
  const deliverable = Array.isArray(row.deliverables) ? row.deliverables[0] : undefined;
  const payment = Array.isArray(row.payments) ? row.payments[0] : undefined;
  const rights = Array.isArray(row.usage_rights) ? row.usage_rights[0] : undefined;

  return {
    id: row.id,
    brandId: row.brand_id,
    brand: brand?.name ?? "Brand",
    campaign: row.campaign_name,
    value: Number(row.deal_value ?? 0),
    currency: row.currency ?? "USD",
    status: row.status,
    platform: row.platform ?? deliverable?.platform ?? "Instagram",
    dueDate: deliverable?.due_date ?? row.start_date ?? new Date().toISOString().slice(0, 10),
    paymentDue: payment?.due_date ?? row.publish_date ?? new Date().toISOString().slice(0, 10),
    paymentStatus: (payment?.status ?? "Pending") as PaymentStatus,
    rightsEnd: rights?.end_date ?? row.publish_date ?? new Date().toISOString().slice(0, 10),
    rightsType: rights?.usage_type ?? "Organic",
    deliverable: deliverable?.deliverable_type ?? "Creator deliverable",
    email: brand?.contact_email ?? "",
    notes: row.notes ?? "",
    createdAt: row.created_at,
  };
}

export default async function DashboardPage() {
  const configured = isSupabaseConfigured();

  if (!configured) {
    const demoUser: AppUser = {
      id: "demo-user",
      name: "Meet Creator",
      email: "demo@dealguard.app",
    };
    const demoPreferences: NotificationPreferences = {
      emailEnabled: true,
      paymentDueDays: [3, 0],
      paymentOverdueDays: [1, 7],
      rightsExpiryDays: [30, 14, 7],
      deliverableDueDays: [3, 1],
    };
    return <DealGuardApp initialDeals={demoDeals} user={demoUser} supabaseEnabled={false} initialPreferences={demoPreferences} initialReminderSummary={{ pendingCount: 0, failedCount: 0 }} />;
  }

  const supabase = await createClient();
  const { data: authData } = await supabase.auth.getUser();
  const user = authData.user;
  if (!user) redirect("/login");

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("onboarding_completed")
    .eq("id", user.id)
    .maybeSingle();

  if (!profileError && profile && !profile.onboarding_completed) redirect("/onboarding");

  const { data, error } = await supabase
    .from("deals")
    .select(`
      id, brand_id, campaign_name, deal_value, currency, status, platform, start_date, publish_date, notes, created_at,
      brands ( id, name, contact_name, contact_email ),
      deliverables ( id, platform, deliverable_type, due_date, publish_date, status ),
      payments ( id, amount, due_date, status, payment_terms ),
      usage_rights ( id, usage_type, start_date, end_date, territory, renewal_price )
    `)
    .order("created_at", { ascending: false });

  if (error) console.error("Failed to load deals", error.message);

  const [{ data: preferenceRow }, { data: reminderRows }] = await Promise.all([
    supabase
      .from("notification_preferences")
      .select("email_enabled,payment_due_days,payment_overdue_days,rights_expiry_days,deliverable_due_days")
      .eq("user_id", user.id)
      .maybeSingle(),
    supabase
      .from("reminders")
      .select("status,reminder_at")
      .in("status", ["pending", "failed"])
      .order("reminder_at", { ascending: true })
      .limit(100),
  ]);

  const preferences: NotificationPreferences = {
    emailEnabled: preferenceRow?.email_enabled ?? true,
    paymentDueDays: preferenceRow?.payment_due_days ?? [3, 0],
    paymentOverdueDays: preferenceRow?.payment_overdue_days ?? [1, 7],
    rightsExpiryDays: preferenceRow?.rights_expiry_days ?? [30, 14, 7],
    deliverableDueDays: preferenceRow?.deliverable_due_days ?? [3, 1],
  };

  const pendingRows = (reminderRows ?? []).filter((row) => row.status === "pending");
  const reminderSummary: ReminderSummary = {
    pendingCount: pendingRows.length,
    failedCount: (reminderRows ?? []).filter((row) => row.status === "failed").length,
    nextReminderAt: pendingRows[0]?.reminder_at,
  };

  const appUser: AppUser = {
    id: user.id,
    name: String(user.user_metadata?.full_name || user.email?.split("@")[0] || "Creator"),
    email: user.email || "",
    avatarUrl: user.user_metadata?.avatar_url,
  };

  return (
    <DealGuardApp
      initialDeals={(data ?? []).map(normalizeDeal)}
      user={appUser}
      supabaseEnabled
      initialPreferences={preferences}
      initialReminderSummary={reminderSummary}
    />
  );
}
